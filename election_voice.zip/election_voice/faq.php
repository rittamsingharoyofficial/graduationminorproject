<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Frequently Asked Questions';
$base = '';
require __DIR__ . '/includes/header.php';

$faqs = [
    [
        'question' => 'What is Election Voice?',
        'answer' => 'Election Voice is an academic online voting project designed to demonstrate voter and candidate management, vote submission, and election reporting.'
    ],
    [
        'question' => 'How do I log in?',
        'answer' => 'Open the Login page and enter the credentials provided by the project administrator. Keep your password private and log out when you finish.'
    ],
    [
        'question' => 'Who can create voter accounts?',
        'answer' => 'In this project, the administrator manages voter accounts and provides login credentials to registered voters.'
    ],
    [
        'question' => 'Can I vote more than once?',
        'answer' => 'The system is designed to allow one vote per voter account for an election. Attempts to vote again should be rejected by the application.'
    ],
    [
        'question' => 'Can I change my vote after submitting it?',
        'answer' => 'The standard voter interface does not allow a submitted vote to be changed. Review your selection carefully before confirming.'
    ],
    [
        'question' => 'How can an administrator manage candidates?',
        'answer' => 'After signing in with an administrator account, authorized administrators can use the candidate management area to add or update candidate information.'
    ],
    [
        'question' => 'Can election results be exported?',
        'answer' => 'The administrator features are designed to display canvassing reports and export supported reports or voter lists in a spreadsheet-compatible format.'
    ],
    [
        'question' => 'Is my vote completely anonymous?',
        'answer' => 'Do not assume that votes are anonymous. Depending on the database design, the application may store voting records linked to voter accounts. This project is for demonstration purposes.'
    ],
    [
        'question' => 'What should I do if I cannot log in?',
        'answer' => 'Check that you are using the correct credentials and that the application is available. If the problem continues, contact the project administrator.'
    ],
    [
        'question' => 'Is Election Voice suitable for official elections?',
        'answer' => 'No. Election Voice is an academic demonstration project and is not certified or approved for public, government, or legally binding elections.'
    ],
    [
        'question' => 'How is my information handled?',
        'answer' => 'The platform may process account details, voting status, election records, and system logs. Please review the Privacy Policy for more information and do not enter unnecessary sensitive information.'
    ],
    [
        'question' => 'How can I contact the project team?',
        'answer' => 'Visit the Contact page on the website to send a question to the project team or administrator.'
    ],
];
?>
<main class="faq-page">
    <section class="page-hero">
        <div class="container">
            <span class="eyebrow">Election Voice · Help Center</span>
            <h1>Frequently Asked Questions</h1>
            <p>Find quick answers about signing in, voting, account management, and election reports.</p>
        </div>
    </section>

    <section class="section">
        <div class="container faq-wrap">
            <div class="faq-search">
                <label for="faqSearch">Search questions</label>
                <input id="faqSearch" type="search" placeholder="e.g. login, vote, results..." autocomplete="off">
                <p id="faqCount" aria-live="polite">12 questions</p>
            </div>

            <div class="faq-list" id="faqList">
                <?php foreach ($faqs as $index => $faq): ?>
                    <details class="faq-item">
                        <summary>
                            <span class="faq-number"><?= str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) ?></span>
                            <span class="faq-question"><?= htmlspecialchars($faq['question'], ENT_QUOTES, 'UTF-8') ?></span>
                            <span class="faq-toggle" aria-hidden="true">+</span>
                        </summary>
                        <div class="faq-answer">
                            <p><?= htmlspecialchars($faq['answer'], ENT_QUOTES, 'UTF-8') ?></p>
                        </div>
                    </details>
                <?php endforeach; ?>
                <p class="faq-empty" id="faqEmpty" hidden>No matching questions found. Try another search term.</p>
            </div>

            <div class="faq-contact">
                <div>
                    <h2>Still have a question?</h2>
                    <p>Contact the Election Voice project team for assistance.</p>
                </div>
                <a class="btn" href="contact.php">Contact Us</a>
            </div>
        </div>
    </section>
</main>

<style>
.faq-wrap{max-width:920px}
.faq-search{padding:22px;margin-bottom:22px;background:#fffaf6;border:1px solid #f0e2d6;border-radius:16px}
.faq-search label{display:block;margin-bottom:8px;font-weight:700;color:#211d19}
.faq-search input{width:100%;box-sizing:border-box;padding:13px 15px;border:1px solid #ded5cd;border-radius:10px;background:#fff;color:#171717;font:inherit;outline:none}
.faq-search input:focus{border-color:#ed7625;box-shadow:0 0 0 3px rgba(237,118,37,.14)}
.faq-search p{margin:9px 0 0;color:#77716a;font-size:.88rem}
.faq-list{display:grid;gap:12px}
.faq-item{border:1px solid #ece5de;border-radius:14px;background:#fff;overflow:hidden;transition:border-color .2s,box-shadow .2s}
.faq-item[open]{border-color:#f1b17f;box-shadow:0 7px 22px rgba(50,30,10,.045)}
.faq-item summary{display:flex;align-items:center;gap:14px;padding:19px 20px;cursor:pointer;list-style:none;color:#191919;font-weight:650}
.faq-item summary::-webkit-details-marker{display:none}
.faq-number{display:grid;place-items:center;flex:0 0 36px;width:36px;height:36px;border-radius:10px;background:#fff0e4;color:#e96b18;font-size:.78rem}
.faq-question{flex:1;line-height:1.5}
.faq-toggle{display:grid;place-items:center;flex:0 0 28px;width:28px;height:28px;border-radius:50%;background:#fff5ed;color:#d96113;font-size:1.3rem;font-weight:400}
.faq-item[open] .faq-toggle{background:#e96b18;color:#fff}
.faq-item[open] .faq-toggle{font-size:0}
.faq-item[open] .faq-toggle:after{content:"−";font-size:1.3rem}
.faq-answer{padding:0 22px 20px 70px}
.faq-answer p{margin:0;color:#5d5751;line-height:1.8}
.faq-empty{padding:20px;text-align:center;color:#6b625a}
.faq-contact{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-top:30px;padding:26px;border-radius:18px;background:#fff1e5;border:1px solid #f7dcc7}
.faq-contact h2{margin:0 0 6px;font-size:1.2rem;color:#211d19}
.faq-contact p{margin:0;color:#655a51;line-height:1.6}
@media(max-width:600px){.faq-item summary{padding:15px 13px;gap:10px}.faq-number{flex-basis:31px;width:31px;height:31px}.faq-answer{padding:0 16px 18px 54px}.faq-contact{align-items:flex-start;flex-direction:column}}
</style>

<script>
(() => {
    const input = document.getElementById('faqSearch');
    const items = Array.from(document.querySelectorAll('.faq-item'));
    const count = document.getElementById('faqCount');
    const empty = document.getElementById('faqEmpty');

    input.addEventListener('input', () => {
        const term = input.value.trim().toLowerCase();
        let visible = 0;
        items.forEach((item) => {
            const matches = item.textContent.toLowerCase().includes(term);
            item.hidden = !matches;
            if (matches) visible++;
            if (!matches) item.open = false;
        });
        count.textContent = `${visible} ${visible === 1 ? 'question' : 'questions'}`;
        empty.hidden = visible !== 0;
    });
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
