<?php
declare(strict_types=1);

/*
 * Election Voice — User Manual page
 * Uses the existing shared header/footer structure.
 */
require_once __DIR__ . '/config.php';

$pageTitle = 'User Manual';
$base = '';

function ev_manual_h(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$manualSections = [
    [
        'id' => 'getting-started',
        'number' => '01',
        'title' => 'Getting started',
        'intro' => 'Use this guide to navigate the Election Voice demo platform.',
        'steps' => [
            'Open the Election Voice home page in your browser.',
            'Use the navigation menu to visit public pages such as About, Candidates, FAQs, Privacy Policy, and Terms & Conditions.',
            'Choose Login when you need to access a voter or administrator account.',
            'Use only the account details issued for your project environment. Never share your password.'
        ]
    ],
    [
        'id' => 'voter-login',
        'number' => '02',
        'title' => 'Voter login',
        'intro' => 'Voter access depends on the account setup configured by the platform administrator.',
        'steps' => [
            'Open the Login page and select the voter login option, if available.',
            'Enter the voter ID or username and password supplied by the administrator.',
            'Submit the form and wait for the voter dashboard to load.',
            'If login fails, check the spelling of your credentials and contact the administrator. Do not send your password through the grievance form.'
        ]
    ],
    [
        'id' => 'candidates',
        'number' => '03',
        'title' => 'Viewing candidates',
        'intro' => 'Review available candidate information before making any decision in a demonstration election.',
        'steps' => [
            'Open the Candidates page from the site navigation.',
            'Use the search field to filter by candidate name, party, or position.',
            'Read the candidate profile and any published manifesto information.',
            'If information appears incorrect or incomplete, submit a grievance with the relevant details.'
        ]
    ],
    [
        'id' => 'voting',
        'number' => '04',
        'title' => 'Casting a vote',
        'intro' => 'Only use the voting flow if it is enabled for your authorized project demo.',
        'steps' => [
            'Sign in with your assigned voter account.',
            'Open the active election and review the instructions shown on screen.',
            'Select your intended option and carefully review your selection.',
            'Submit the vote only when you are ready. If the system confirms submission, keep the confirmation shown by the application.',
            'The demo is intended for academic/project use and is not an official legally binding election.'
        ]
    ],
    [
        'id' => 'grievances',
        'number' => '05',
        'title' => 'Submitting a grievance',
        'intro' => 'Use the Voter Grievance Portal to report account, access, or candidate-information issues.',
        'steps' => [
            'Open the Grievance Portal page.',
            'Enter your name and a valid email address, then select a category.',
            'Provide a short subject and explain what happened, including useful non-sensitive details.',
            'Submit the form and save the reference number displayed on screen.',
            'Do not include passwords, financial details, or unnecessary identity information.'
        ]
    ],
    [
        'id' => 'newsletter',
        'number' => '06',
        'title' => 'Newsletter subscription',
        'intro' => 'If newsletter signup is enabled, you can subscribe to receive project updates.',
        'steps' => [
            'Find the newsletter form in the website footer.',
            'Enter a valid email address and select Subscribe.',
            'If a status message appears, follow the instructions shown.',
            'Only subscribe with an email address you are authorized to use.'
        ]
    ],
    [
        'id' => 'troubleshooting',
        'number' => '07',
        'title' => 'Troubleshooting',
        'intro' => 'Try these checks when a page or feature does not work as expected.',
        'steps' => [
            'Refresh the page and check that Apache and MySQL are running in XAMPP.',
            'Confirm that the project folder is inside the XAMPP htdocs directory.',
            'Check that the database has been imported and config.php uses the correct database name and credentials.',
            'If a page shows a database error, ask the project administrator to inspect the PHP error log rather than exposing database details publicly.',
            'If you cannot access your account, request help from the administrator; do not attempt to access another person’s account.'
        ]
    ],
    [
        'id' => 'privacy-safety',
        'number' => '08',
        'title' => 'Privacy and safe use',
        'intro' => 'Help keep the platform and account information secure.',
        'steps' => [
            'Use only your own assigned account and sign out when finished on a shared computer.',
            'Do not share login credentials or attempt to change another user’s data.',
            'Submit accurate grievance details and avoid unnecessary personal information.',
            'Review the Privacy Policy and Terms & Conditions pages for the project’s stated practices.',
            'Do not use this academic demo to conduct an official public election or store sensitive real-world election data.'
        ]
    ]
];

require __DIR__ . '/includes/header.php';
?>

<main class="ev-manual-page">
    <section class="ev-manual-hero">
        <div class="ev-manual-hero-copy">
            <span class="ev-manual-eyebrow">ELECTION VOICE · HELP CENTRE</span>
            <h1>User <span>manual</span></h1>
            <p>A practical, step-by-step guide to navigating Election Voice, accessing voter features, viewing candidates, and getting help.</p>
            <a class="ev-manual-hero-button" href="#manual-content">Read the guide <span aria-hidden="true">↓</span></a>
        </div>
        <div class="ev-manual-hero-graphic" aria-hidden="true">
            <div class="ev-manual-paper">
                <div class="ev-paper-mark">EV</div>
                <div class="ev-paper-line"></div>
                <div class="ev-paper-line medium"></div>
                <div class="ev-paper-check"><span>✓</span> Step-by-step guide</div>
                <div class="ev-paper-line"></div>
                <div class="ev-paper-line short"></div>
            </div>
            <div class="ev-manual-circle"></div>
        </div>
    </section>

    <section class="ev-manual-layout" id="manual-content">
        <aside class="ev-manual-sidebar">
            <div class="ev-manual-sidebar-title">IN THIS MANUAL</div>
            <label class="ev-manual-search-label" for="manualSearch">Search guide</label>
            <input class="ev-manual-search" id="manualSearch" type="search" placeholder="Search topics…">
            <nav class="ev-manual-nav" aria-label="User manual sections">
                <?php foreach ($manualSections as $section): ?>
                    <a href="#<?= ev_manual_h($section['id']) ?>">
                        <span><?= ev_manual_h($section['number']) ?></span>
                        <?= ev_manual_h($section['title']) ?>
                    </a>
                <?php endforeach; ?>
            </nav>

        </aside>

        <div class="ev-manual-main">
            <div class="ev-manual-welcome">
                <span class="ev-manual-eyebrow">QUICK START</span>
                <h2>Welcome to Election Voice</h2>
                <p>This manual explains the main pages and typical user workflows. Some actions may vary depending on which features have been enabled in your installation.</p>
            </div>

            <?php foreach ($manualSections as $section): ?>
                <article class="ev-manual-section" id="<?= ev_manual_h($section['id']) ?>" data-manual-search="<?= ev_manual_h(strtolower($section['title'] . ' ' . $section['intro'] . ' ' . implode(' ', $section['steps']))) ?>">
                    <div class="ev-manual-section-number"><?= ev_manual_h($section['number']) ?></div>
                    <div class="ev-manual-section-content">
                        <h3><?= ev_manual_h($section['title']) ?></h3>
                        <p class="ev-manual-intro"><?= ev_manual_h($section['intro']) ?></p>
                        <ol>
                            <?php foreach ($section['steps'] as $step): ?>
                                <li><?= ev_manual_h($step) ?></li>
                            <?php endforeach; ?>
                        </ol>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="ev-manual-no-results" id="manualNoResults" hidden>No manual sections match your search.</div>

            <section class="ev-manual-final-note">
                <div class="ev-final-note-icon" aria-hidden="true">i</div>
                <div>
                    <h3>Important notice</h3>
                    <p>Election Voice is an academic/demo project. Features and workflows depend on your installed version. Do not use this platform as a substitute for official election services.</p>
                </div>
            </section>
        </div>
    </section>
</main>

<style>
.ev-manual-page{background:#fff;color:#171717;font-family:inherit}
.ev-manual-page *{box-sizing:border-box}
.ev-manual-hero{display:flex;align-items:center;justify-content:space-between;gap:36px;min-height:325px;padding:clamp(32px,6vw,74px) clamp(22px,7vw,90px);overflow:hidden;background:#fff3e8;border-bottom:1px solid #ffdec5}
.ev-manual-hero-copy{max-width:670px}
.ev-manual-eyebrow{color:#d95e0b;font-size:.74rem;letter-spacing:.15em;font-weight:850}
.ev-manual-hero h1{margin:14px 0;font-size:clamp(2.7rem,5.5vw,4.6rem);line-height:1.03;letter-spacing:-.05em}
.ev-manual-hero h1 span{color:#f47721}
.ev-manual-hero-copy>p{max-width:620px;color:#555;font-size:1.04rem;line-height:1.8}
.ev-manual-hero-button{display:inline-flex;gap:12px;align-items:center;margin-top:10px;padding:13px 18px;border-radius:9px;background:#f47721;color:#fff;text-decoration:none;font-weight:800}
.ev-manual-hero-button:hover{background:#d95e0b}
.ev-manual-hero-graphic{position:relative;display:grid;place-items:center;flex:0 0 270px;min-height:230px}
.ev-manual-circle{position:absolute;z-index:0;right:0;top:0;width:220px;height:220px;border-radius:50%;background:#ffc18e;opacity:.7}
.ev-manual-paper{position:relative;z-index:1;width:190px;padding:20px;border:1px solid #f2d6c2;border-radius:14px;background:#fff;box-shadow:0 20px 45px #793d1a17;transform:rotate(4deg)}
.ev-paper-mark{display:grid;place-items:center;width:34px;height:34px;margin-bottom:20px;border-radius:9px;background:#fff0e4;color:#e66c18;font-weight:900}
.ev-paper-line{height:7px;margin:11px 0;border-radius:8px;background:#eee6df}
.ev-paper-line.medium{width:78%}.ev-paper-line.short{width:54%}
.ev-paper-check{display:flex;align-items:center;gap:8px;margin:16px 0;color:#555;font-size:.75rem;font-weight:750}
.ev-paper-check span{display:grid;place-items:center;width:22px;height:22px;border-radius:50%;background:#ffe4cf;color:#d95e0b}
.ev-manual-layout{display:grid;grid-template-columns:255px minmax(0,1fr);gap:42px;max-width:1250px;margin:0 auto;padding:42px 22px 70px}
.ev-manual-sidebar{align-self:start;position:sticky;top:24px;padding:20px;border:1px solid #eee0d6;border-radius:14px;background:#fff}
.ev-manual-sidebar-title{margin-bottom:16px;color:#777;font-size:.7rem;letter-spacing:.13em;font-weight:900}
.ev-manual-search-label{display:block;margin-bottom:7px;font-size:.82rem;font-weight:750}
.ev-manual-search{width:100%;padding:10px 11px;border:1px solid #ddd;border-radius:8px;font:inherit}
.ev-manual-search:focus{outline:0;border-color:#f47721;box-shadow:0 0 0 3px #f4772120}
.ev-manual-nav{display:grid;gap:4px;margin-top:15px}
.ev-manual-nav a{display:flex;align-items:center;gap:10px;padding:10px 8px;border-radius:8px;color:#444;text-decoration:none;font-size:.88rem}
.ev-manual-nav a:hover{background:#fff2e8;color:#c65a12}
.ev-manual-nav a span{color:#d96a1b;font-size:.7rem;font-weight:900}
.ev-manual-help-card{margin-top:20px;padding:15px;border-radius:10px;background:#fff3e8}
.ev-manual-help-card strong{font-size:.9rem}
.ev-manual-help-card p{margin:7px 0;color:#666;font-size:.82rem;line-height:1.55}
.ev-manual-help-card a{color:#bd4d09;text-decoration:none;font-size:.82rem;font-weight:800}
.ev-manual-main{min-width:0}
.ev-manual-welcome{padding:5px 0 24px}
.ev-manual-welcome h2{margin:9px 0;font-size:clamp(1.7rem,3vw,2.3rem);letter-spacing:-.035em}
.ev-manual-welcome p{color:#666;line-height:1.75}
.ev-manual-section{display:grid;grid-template-columns:46px minmax(0,1fr);gap:17px;padding:25px 0;border-top:1px solid #eee7e1;scroll-margin-top:24px}
.ev-manual-section-number{display:grid;place-items:center;width:42px;height:42px;border-radius:12px;background:#fff0e4;color:#d95e0b;font-size:.8rem;font-weight:900}
.ev-manual-section-content h3{margin:3px 0 8px;font-size:1.25rem}
.ev-manual-intro{margin:0 0 14px;color:#666;line-height:1.7}
.ev-manual-section ol{margin:0;padding-left:22px;color:#444;line-height:1.8}
.ev-manual-section li{padding:3px 0 3px 4px}
.ev-manual-section li::marker{color:#e66c18;font-weight:800}
.ev-manual-final-note{display:flex;gap:14px;margin-top:28px;padding:20px;border:1px solid #f0d0ba;border-radius:12px;background:#fff8f2}
.ev-final-note-icon{display:grid;place-items:center;flex:0 0 28px;height:28px;border-radius:50%;background:#ffe4cf;color:#b84e0c;font-weight:900}
.ev-manual-final-note h3{margin:2px 0 7px;font-size:1rem}
.ev-manual-final-note p{margin:0;color:#6a574b;line-height:1.7;font-size:.9rem}
.ev-manual-no-results{padding:24px;border-radius:10px;background:#fff8f2;color:#666;text-align:center}
@media(max-width:850px){.ev-manual-layout{grid-template-columns:1fr;gap:24px}.ev-manual-sidebar{position:static}.ev-manual-nav{grid-template-columns:repeat(2,minmax(0,1fr))}.ev-manual-help-card{margin-top:15px}}
@media(max-width:600px){.ev-manual-hero{padding:34px 22px}.ev-manual-hero-graphic{display:none}.ev-manual-nav{grid-template-columns:1fr}.ev-manual-layout{padding:25px 16px 45px}.ev-manual-section{grid-template-columns:36px minmax(0,1fr);gap:12px}.ev-manual-section-number{width:34px;height:34px;border-radius:9px}}
@media(prefers-reduced-motion:reduce){.ev-manual-hero-button{transition:none}}
</style>

<script>
(() => {
    const input = document.getElementById('manualSearch');
    const sections = Array.from(document.querySelectorAll('[data-manual-search]'));
    const links = Array.from(document.querySelectorAll('.ev-manual-nav a'));
    const noResults = document.getElementById('manualNoResults');
    if (!input) return;

    input.addEventListener('input', () => {
        const query = input.value.trim().toLocaleLowerCase();
        let visible = 0;

        sections.forEach(section => {
            const matches = (section.dataset.manualSearch || '').includes(query);
            section.hidden = !matches;
            if (matches) visible++;
        });

        links.forEach(link => {
            const target = document.querySelector(link.getAttribute('href'));
            link.hidden = !!target && target.hidden;
        });

        if (noResults) noResults.hidden = visible !== 0;
    });
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
