<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Terms & Conditions';
$base = '';
require __DIR__ . '/includes/header.php';
?>
<main class="terms-page">
<section class="page-hero"><div class="container">
<span class="eyebrow">Election Voice · Legal Information</span>
<h1>Terms &amp; Conditions</h1>
<p>Please read these terms carefully before using the Election Voice online voting platform.</p>
</div></section>
<section class="section"><div class="container terms-layout">
<aside class="terms-sidebar"><h2>On this page</h2><nav aria-label="Terms sections">
<a href="#introduction">1. Introduction</a><a href="#purpose">2. Purpose of the Platform</a><a href="#accounts">3. User Accounts</a><a href="#voting">4. Voting Rules</a><a href="#admin">5. Administrator Responsibilities</a><a href="#acceptable-use">6. Acceptable Use</a><a href="#privacy">7. Data and Privacy</a><a href="#availability">8. Accuracy and Availability</a><a href="#disclaimer">9. Educational Use Disclaimer</a><a href="#liability">10. Limitation of Liability</a><a href="#changes">11. Changes to These Terms</a><a href="#contact">12. Contact Information</a>
</nav></aside>
<article class="terms-content">
<section id="introduction"><h2><span>01</span> Introduction</h2><p>Welcome to Election Voice, an online voting platform developed as an academic project. By accessing or using this platform, you agree to comply with these Terms &amp; Conditions.</p></section>
<section id="purpose"><h2><span>02</span> Purpose of the Platform</h2><p>Election Voice is designed to demonstrate digital voting functionality for educational purposes, including candidate management, voter registration, vote submission, and election reporting.</p></section>
<section id="accounts"><h2><span>03</span> User Accounts</h2><ul><li>Users must log in using valid credentials provided by the administrator.</li><li>Users are responsible for keeping their login credentials confidential.</li><li>Users must not share accounts or attempt to access another user's account without authorization.</li><li>Administrators are responsible for managing voter accounts and candidate information appropriately.</li></ul></section>
<section id="voting"><h2><span>04</span> Voting Rules</h2><ul><li>Each registered voter account is permitted to submit only one vote per election in the system's current implementation.</li><li>Users should review their selection before submitting their vote.</li><li>Once submitted, a vote cannot be changed through the standard voter interface.</li><li>Users must not attempt to manipulate voting results, submit duplicate votes, or interfere with the voting process.</li></ul></section>
<section id="admin"><h2><span>05</span> Administrator Responsibilities</h2><p>Administrators may manage candidates and voter accounts, review canvassing reports, export reports, and access system activity logs. Administrative access must be used responsibly and only for authorized project purposes.</p></section>
<section id="acceptable-use"><h2><span>06</span> Acceptable Use</h2><p>Users must not:</p><ul><li>Attempt unauthorized access to the platform or its database.</li><li>Modify, damage, or disrupt system functionality.</li><li>Use automated methods to manipulate votes or election reports.</li><li>Upload malicious files or submit harmful code.</li><li>Misuse, disclose, or distribute other users' information without authorization.</li></ul></section>
<section id="privacy"><h2><span>07</span> Data and Privacy</h2><p>The platform may store account details, password hashes, voting records, and system activity logs to support its functionality. Users should not submit unnecessary sensitive or confidential personal information.</p><p>Project administrators should protect stored information and restrict access to authorized individuals. This demonstration system does not guarantee complete anonymity or confidentiality of voting records.</p></section>
<section id="availability"><h2><span>08</span> Accuracy and Availability</h2><p>Election Voice is provided for demonstration purposes. The platform may contain errors, experience interruptions, or produce inaccurate results due to software defects, configuration issues, or unauthorized modifications. Independent verification is necessary before relying on any results.</p></section>
<section id="disclaimer"><h2><span>09</span> Educational Use Disclaimer</h2><p>Election Voice is an academic demonstration project and is <strong>not certified or approved for public, government, or legally binding elections</strong>. It does not replace independently audited election infrastructure, official voter verification, or legally required election procedures.</p></section>
<section id="liability"><h2><span>10</span> Limitation of Liability</h2><p>To the extent permitted by applicable law, the project developer is not responsible for losses or consequences arising from the use, misuse, interruption, or reliance on this demonstration platform. This section does not exclude liability that cannot legally be excluded.</p></section>
<section id="changes"><h2><span>11</span> Changes to These Terms</h2><p>These Terms &amp; Conditions may be updated when the platform's features or project requirements change. The latest version should be published on this page.</p></section>
<section id="contact"><h2><span>12</span> Contact Information</h2><p>For questions about these Terms &amp; Conditions or the Election Voice academic project, please use the Contact page available on the platform.</p><a class="btn" href="contact.php">Contact Election Voice</a></section>
<div class="terms-acknowledgement"><strong>By using Election Voice, you acknowledge that you have read and understood these Terms &amp; Conditions.</strong></div>
</article></div></section></main>
<style>
.terms-layout{display:grid;grid-template-columns:270px minmax(0,1fr);gap:32px;align-items:start}
.terms-sidebar{position:sticky;top:105px;padding:22px;background:#fffaf6;border:1px solid #f0e2d6;border-radius:18px}
.terms-sidebar h2{font-size:1.05rem;margin:0 0 12px}.terms-sidebar nav{display:grid;gap:4px}
.terms-sidebar nav a{padding:8px 10px;border-radius:8px;font-size:.88rem;color:#514942}
.terms-sidebar nav a:hover{background:#ffead9;color:#b94d0a}
.terms-content{min-width:0;padding:clamp(20px,4vw,42px);border:1px solid #ece7e2;border-radius:22px;box-shadow:0 8px 26px rgba(30,20,10,.035)}
.terms-content section{scroll-margin-top:110px;padding:0 0 25px;margin:0 0 26px;border-bottom:1px solid #eee7e0}
.terms-content section:last-of-type{border-bottom:0;margin-bottom:0}
.terms-content h2{font-size:1.3rem;letter-spacing:-.025em;display:flex;align-items:center;gap:12px;margin:0 0 12px}
.terms-content h2 span{display:inline-grid;place-items:center;flex:0 0 38px;width:38px;height:38px;border-radius:12px;background:#fff0e4;color:#e96b18;font-size:.8rem;letter-spacing:0}
.terms-content p,.terms-content li{color:#55504b;line-height:1.8}.terms-content ul{padding-left:23px}.terms-content li{padding:3px 0}
.terms-acknowledgement{margin-top:28px;padding:20px;border-left:4px solid #f47721;border-radius:0 12px 12px 0;background:#fff5ec;line-height:1.7}
@media(max-width:850px){.terms-layout{grid-template-columns:1fr}.terms-sidebar{position:static}.terms-sidebar nav{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:520px){.terms-sidebar nav{grid-template-columns:1fr}.terms-content{padding:20px}.terms-content h2{font-size:1.12rem}}
</style>
<?php require __DIR__ . '/includes/footer.php'; ?>
