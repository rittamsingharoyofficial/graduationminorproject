# Election Voice — PHP & MySQL Minor Project

Election Voice is a responsive online voting **demonstration** built with PHP 8.2+, MySQL/MariaDB, HTML, CSS and JavaScript. It includes the supplied Election Voice logo, a public header/footer, Home/About/Blog/Contact pages, login, admin management, voter ballot, CSV exports and system logs.

## Run with Windows XAMPP
1. Extract the `election_voice` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** from XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin/`.
4. Import `database.sql` (or go directly to step 5; setup.php also creates the database and tables).
5. Visit `http://localhost/election_voice/setup.php` once.
6. Open `http://localhost/election_voice/`.
7. After setup, **delete `setup.php`** and change the demo passwords before showing the project.

## Demo credentials
- Admin: `admin` / `admin123`
- Voter: `voter01` / `voter123`

Admin can add candidates and voter accounts, see vote totals and turnout, export voter/report CSVs (openable in Excel), and view recent system logs. Voters can submit one vote only. The `votes.voter_id` unique key and a transaction/server-side check prevent a second vote per account.

## Database configuration
Default XAMPP values are in `config.php` (`root` with an empty password). Change `DB_USER` and `DB_PASS` to match your local environment.

## Important limitations
This is for an academic/minor project and demo elections only. It is **not suitable for public, government, or legally binding elections**. It does not implement independently verifiable ballots, cryptographic end-to-end verification, voter identity proofing, a formal threat model, or external security certification. Do not deploy it publicly as-is. CSV exports contain administrative data and must be kept private.
