<?php
require_once __DIR__ . '/config.php';
$message = '';
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `" . DB_NAME . "`");
    $schema = file_get_contents(__DIR__ . '/database.sql');
    // Run the schema statements after stripping database selection lines.
    $schema = preg_replace('/CREATE DATABASE.*?;|USE election_voice;/is', '', $schema);
    foreach (array_filter(array_map('trim', explode(';', $schema))) as $statement) $pdo->exec($statement);

    $check = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $check->execute(['admin']);
    if (!$check->fetch()) {
        $insert = $pdo->prepare('INSERT INTO users (full_name, username, password_hash, role) VALUES (?, ?, ?, ?)');
        $insert->execute(['Election Voice Admin', 'admin', password_hash('admin123', PASSWORD_DEFAULT), 'admin']);
    }
    $check->execute(['voter01']);
    if (!$check->fetch()) {
        $insert = $pdo->prepare('INSERT INTO users (full_name, username, password_hash, role) VALUES (?, ?, ?, ?)');
        $insert->execute(['Demo Voter', 'voter01', password_hash('voter123', PASSWORD_DEFAULT), 'voter']);
    }
    $count = (int)$pdo->query('SELECT COUNT(*) FROM candidates')->fetchColumn();
    if ($count === 0) {
        $pdo->exec("INSERT INTO candidates (full_name, position_name, party_name, manifesto) VALUES
        ('Aarav Sen', 'Student Council President', 'Progress Group', 'More student-led events and transparent communication.'),
        ('Mira Das', 'Student Council President', 'Campus First', 'A cleaner campus and more inclusive activities.'),
        ('Rohan Ghosh', 'Student Council President', 'Unity Panel', 'Better student support and collaborative clubs.')");
    }
    $message = 'Setup complete. Demo admin: admin / admin123. Demo voter: voter01 / voter123.';
} catch (Throwable $ex) {
    $message = 'Setup failed: ' . $ex->getMessage();
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Election Voice Setup</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="setup-page"><main class="auth-card"><img class="auth-logo" src="assets/election-voice-logo.png" alt="Election Voice logo"><h1>Election Voice Setup</h1><p><?= e($message) ?></p><a class="btn" href="index.php">Open platform</a><p class="muted small">For security, delete setup.php after successful setup and change the demo passwords.</p></main></body></html>
