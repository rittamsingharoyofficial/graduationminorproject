<?php
require_once __DIR__ . '/../config.php'; require_role('voter'); $pageTitle='Voter Portal'; $base='../'; $pdo=db(); $error='';
if($_SERVER['REQUEST_METHOD']==='POST') {
 verify_csrf(); $candidateId=(int)($_POST['candidate_id']??0);
 try {
  $pdo->beginTransaction();
  $s=$pdo->prepare("SELECT id,has_voted FROM users WHERE id=? AND role='voter' FOR UPDATE"); $s->execute([$_SESSION['user_id']]); $voter=$s->fetch();
  if(!$voter) throw new RuntimeException('Voter account not found.');
  if((int)$voter['has_voted']===1) throw new RuntimeException('Your account has already voted. A second vote is not allowed.');
  $s=$pdo->prepare('SELECT id FROM candidates WHERE id=?'); $s->execute([$candidateId]); if(!$s->fetch()) throw new RuntimeException('Please select a valid candidate.');
  $s=$pdo->prepare('INSERT INTO votes(voter_id,candidate_id) VALUES(?,?)'); $s->execute([$_SESSION['user_id'],$candidateId]);
  $s=$pdo->prepare('UPDATE users SET has_voted=1 WHERE id=?'); $s->execute([$_SESSION['user_id']]);
  $pdo->commit(); log_action('Submitted vote'); flash('Your vote has been recorded. Thank you for participating.'); header('Location: dashboard.php'); exit;
 } catch(Throwable $ex) { if($pdo->inTransaction()) $pdo->rollBack(); $error=$ex instanceof PDOException?'Your vote could not be recorded. Please refresh and check your account status.':$ex->getMessage(); }
}
$s=$pdo->prepare('SELECT has_voted FROM users WHERE id=?'); $s->execute([$_SESSION['user_id']]); $hasVoted=(bool)$s->fetchColumn();
$candidates=$pdo->query('SELECT id,full_name,position_name,party_name,manifesto FROM candidates ORDER BY position_name,full_name')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<main class="dashboard"><div class="container"><div class="dash-head"><div><span class="eyebrow">Voter portal</span><h1>Hello, <?= e($_SESSION['full_name']) ?>.</h1><p class="muted">Review the candidates and make your selection carefully.</p></div><span class="pill"><?= $hasVoted?'Vote submitted':'Ready to vote' ?></span></div>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<?php if($hasVoted): ?><section class="panel"><h2>Thank you for participating.</h2><p>Your account has already submitted a vote. The system will not accept another vote from this account.</p><p class="muted small">This demo does not provide individual ballot receipts or cryptographic election verification.</p></section>
<?php else: ?><div class="alert info">Please confirm your choice before submitting. A submitted vote cannot be changed from this interface.</div><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><div class="cards"><?php foreach($candidates as $c): ?><label class="feature-card" style="display:block;cursor:pointer"><input type="radio" name="candidate_id" value="<?= (int)$c['id'] ?>" required style="accent-color:#f47721;transform:scale(1.2);margin-right:8px"><b><?= e($c['full_name']) ?></b><div class="pill" style="margin-top:10px"><?= e($c['position_name']) ?></div><p><b>Group:</b> <?= e($c['party_name']) ?></p><p><?= e($c['manifesto']) ?></p></label><?php endforeach; ?></div><?php if($candidates): ?><p style="margin-top:24px"><button class="btn" type="submit" data-confirm="Submit your vote? This action cannot be undone.">Submit my vote →</button></p><?php else: ?><div class="empty-state">No candidates are available yet. Please contact the administrator.</div><?php endif; ?></form><?php endif; ?>
</div></main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
