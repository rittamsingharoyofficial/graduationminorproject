<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Privacy Policy';
$base = '';
require __DIR__ . '/includes/header.php';
?>
<main class="privacy-page">
    <section class="page-hero">
        <div class="container">
            <span class="eyebrow">Election Voice · Your Privacy</span>
            <h1>Privacy Policy</h1>
            <p>This page explains how Election Voice may collect, use, and protect information when you use this academic voting platform.</p>
        </div>
    </section>

    <section class="section">
        <div class="container privacy-layout">
            <aside class="privacy-sidebar">
                <h2>On this page</h2>
                <nav aria-label="Privacy policy sections">
                    <a href="#overview">1. Overview</a>
                    <a href="#information">2. Information We May Collect</a>
                    <a href="#use">3. How Information Is Used</a>
                    <a href="#voting-data">4. Voting Data</a>
                    <a href="#sharing">5. Sharing and Disclosure</a>
                    <a href="#security">6. Data Security</a>
                    <a href="#retention">7. Data Retention</a>
                    <a href="#rights">8. Your Choices and Requests</a>
                    <a href="#cookies">9. Cookies and Sessions</a>
                    <a href="#children">10. Children’s Privacy</a>
                    <a href="#changes">11. Policy Updates</a>
                    <a href="#contact">12. Contact</a>
                </nav>
            </aside>

            <article class="privacy-content">
                <section id="overview">
                    <h2><span>01</span> Overview</h2>
                    <p>Election Voice is an online voting platform developed for academic and demonstration purposes. This policy describes the types of information the platform may process and the ways project administrators should handle it.</p>
                    <p>Use this policy as a project template and update it to match the data your actual installation collects, the people who can access it, and your institution’s requirements.</p>
                </section>

                <section id="information">
                    <h2><span>02</span> Information We May Collect</h2>
                    <p>Depending on how the platform is configured, it may process:</p>
                    <ul>
                        <li><strong>Account information:</strong> usernames, voter identifiers, names, and other details entered by an administrator.</li>
                        <li><strong>Authentication data:</strong> password hashes and session-related information used to sign users in.</li>
                        <li><strong>Election information:</strong> candidate details, voting status, ballot records, and election totals.</li>
                        <li><strong>Activity records:</strong> administrative actions and technical logs used for troubleshooting and accountability.</li>
                        <li><strong>Messages:</strong> information a user chooses to provide through the contact form, if one is enabled.</li>
                    </ul>
                    <p>Do not enter unnecessary sensitive personal information into this academic demonstration system.</p>
                </section>

                <section id="use">
                    <h2><span>03</span> How Information Is Used</h2>
                    <p>Information may be used to operate user accounts, administer candidates and voters, record voting status, calculate and display election results, generate reports, maintain system security, and troubleshoot technical problems.</p>
                </section>

                <section id="voting-data">
                    <h2><span>04</span> Voting Data</h2>
                    <p>The platform may store a record that a voter has voted and may associate a ballot with an account, depending on its database design. Therefore, this project should not be assumed to provide anonymous voting.</p>
                    <p>Access to ballots and reports should be restricted to authorized people. Do not use this demonstration platform for real, public, government, or legally binding elections.</p>
                </section>

                <section id="sharing">
                    <h2><span>05</span> Sharing and Disclosure</h2>
                    <p>Information should only be accessed or disclosed when needed to operate or maintain the project, when authorized by the responsible project administrator, or when disclosure is required by applicable law. Exported voter lists and reports should be handled securely and shared only with authorized recipients.</p>
                    <p>This template does not assume that Election Voice sells personal information or shares it with advertising companies. Review your hosting, analytics, email, and other integrations and revise this section if they process information.</p>
                </section>

                <section id="security">
                    <h2><span>06</span> Data Security</h2>
                    <p>Reasonable safeguards should be used to protect stored information, including password hashing, access controls, secure configuration, database backups, and timely software updates. No website or storage system can be guaranteed completely secure.</p>
                    <p>Change demonstration credentials before deployment, restrict access to administrative accounts, and remove installation or setup scripts after configuration.</p>
                </section>

                <section id="retention">
                    <h2><span>07</span> Data Retention</h2>
                    <p>Information may be retained for as long as necessary to run the project, maintain appropriate records, resolve issues, or meet applicable requirements. The project administrator should define a retention and deletion process and securely remove data that is no longer needed, subject to any legal or institutional obligations.</p>
                </section>

                <section id="rights">
                    <h2><span>08</span> Your Choices and Requests</h2>
                    <p>Subject to applicable law and the needs of the election record, users may contact the project administrator to ask about their personal information or request correction or deletion where appropriate. Some records may need to be retained to preserve the integrity of a demonstration election or meet applicable requirements.</p>
                </section>

                <section id="cookies">
                    <h2><span>09</span> Cookies and Sessions</h2>
                    <p>The platform may use session cookies or similar browser storage to maintain login sessions and protect authenticated pages. These are used for platform functionality rather than advertising unless additional services are installed. Users can manage cookies through their browser settings, though disabling them may prevent login features from working properly.</p>
                </section>

                <section id="children">
                    <h2><span>10</span> Children’s Privacy</h2>
                    <p>This academic project is not designed to collect personal information from children without appropriate authorization. If you believe information has been entered improperly, contact the project administrator so it can be reviewed and handled appropriately.</p>
                </section>

                <section id="changes">
                    <h2><span>11</span> Policy Updates</h2>
                    <p>This Privacy Policy may be revised when the platform or its data practices change. The latest version and update date should be published on this page.</p>
                </section>

                <section id="contact">
                    <h2><span>12</span> Contact</h2>
                    <p>For questions about this policy or information handled by the Election Voice project, please use the Contact page or contact the project administrator.</p>
                    <a class="btn" href="contact.php">Contact Election Voice</a>
                </section>

                <div class="privacy-notice">
                    <strong>Academic project notice:</strong> Election Voice is a demonstration platform, not a certified election system. This policy is a template and should be reviewed and adapted to your actual implementation before public deployment.
                </div>
            </article>
        </div>
    </section>
</main>

<style>
.privacy-layout{display:grid;grid-template-columns:270px minmax(0,1fr);gap:32px;align-items:start}
.privacy-sidebar{position:sticky;top:105px;padding:22px;background:#fffaf6;border:1px solid #f0e2d6;border-radius:18px}
.privacy-sidebar h2{font-size:1.05rem;margin:0 0 12px}
.privacy-sidebar nav{display:grid;gap:4px}
.privacy-sidebar nav a{padding:8px 10px;border-radius:8px;font-size:.88rem;color:#514942}
.privacy-sidebar nav a:hover{background:#ffead9;color:#b94d0a}
.privacy-content{min-width:0;padding:clamp(20px,4vw,42px);border:1px solid #ece7e2;border-radius:22px;box-shadow:0 8px 26px rgba(30,20,10,.035)}
.privacy-content section{scroll-margin-top:110px;padding:0 0 25px;margin:0 0 26px;border-bottom:1px solid #eee7e0}
.privacy-content section:last-of-type{border-bottom:0;margin-bottom:0}
.privacy-content h2{font-size:1.3rem;letter-spacing:-.025em;display:flex;align-items:center;gap:12px;margin:0 0 12px}
.privacy-content h2 span{display:inline-grid;place-items:center;flex:0 0 38px;width:38px;height:38px;border-radius:12px;background:#fff0e4;color:#e96b18;font-size:.8rem;letter-spacing:0}
.privacy-content p,.privacy-content li{color:#55504b;line-height:1.8}
.privacy-content ul{padding-left:23px}
.privacy-content li{padding:3px 0}
.privacy-notice{margin-top:28px;padding:20px;border-left:4px solid #f47721;border-radius:0 12px 12px 0;background:#fff5ec;line-height:1.7;color:#514942}
@media(max-width:850px){.privacy-layout{grid-template-columns:1fr}.privacy-sidebar{position:static}.privacy-sidebar nav{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:520px){.privacy-sidebar nav{grid-template-columns:1fr}.privacy-content{padding:20px}.privacy-content h2{font-size:1.12rem}}
</style>

<?php require __DIR__ . '/includes/footer.php'; ?>
