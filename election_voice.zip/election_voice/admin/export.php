<?php
require_once __DIR__ . '/../config.php'; require_role('admin');
$type=$_GET['type']??'';
if($type==='voters') { $rows=db()->query("SELECT full_name,username,has_voted,created_at FROM users WHERE role='voter' ORDER BY full_name")->fetchAll(); $filename='election-voice-voters.csv'; $headers=['Full name','Username','Has voted','Created at']; }
elseif($type==='report') { $rows=db()->query("SELECT c.full_name,c.position_name,c.party_name,COUNT(v.id) AS total_votes FROM candidates c LEFT JOIN votes v ON v.candidate_id=c.id GROUP BY c.id ORDER BY total_votes DESC,c.full_name")->fetchAll(); $filename='election-voice-canvassing-report.csv'; $headers=['Candidate','Position','Group','Total votes']; }
else { http_response_code(400); exit('Invalid export type.'); }
header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="'.$filename.'"');
$out=fopen('php://output','w'); fputcsv($out,$headers); foreach($rows as $row) fputcsv($out,array_values($row)); fclose($out); log_action('Exported '.$type.' CSV'); exit;
?>
