<?php require_once __DIR__ . '/config.php'; $pageTitle='Blog'; $base=''; require __DIR__ . '/includes/header.php'; ?>
<section class="page-hero"><div class="container"><span class="eyebrow">Election Voice journal</span><h1>Ideas for better participation.</h1><p>Short reads about digital voting, usability, and responsible project design.</p></div></section>
<section class="section"><div class="container cards">
<article class="content-card"><span class="pill">UX basics</span><h2>Why a clear ballot matters</h2><p>A voting interface should make the choices understandable, keep instructions visible, and avoid unnecessary distractions before submission.</p></article>
<article class="content-card"><span class="pill">Security</span><h2>One-vote enforcement</h2><p>Do not rely only on a hidden button or browser state. Validate the voter on the server and enforce uniqueness in the database.</p></article>
<article class="content-card"><span class="pill">Transparency</span><h2>Reports that people can read</h2><p>Useful reports present candidate totals, turnout, and exportable data while restricting administrative access to authorized users.</p></article>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
