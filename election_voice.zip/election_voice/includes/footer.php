<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-brand"><div class="brand brand-light"><img src="<?= $base ?? '' ?>assets/election-voice-logo.png" alt=""><span>Election <b>Voice</b></span></div><p>Election Voice is a modern online voting platform designed to make digital elections simple, accessible, and transparent. Our goal is to encourage participation through secure voting and easy-to-use technology.</p></div>
     <div><h3>Quick Links</h3><a href="<?= $base ?? '' ?>home.php">Home</a><a href="<?= $base ?? '' ?>about.php">About</a><a href="<?= $base ?? '' ?>insights.php">Insights</a></div>
    <div><h3>Official Pages</h3><a href="<?= $base ?? '' ?>terms.php">Terms & Conditions</a><a href="<?= $base ?? '' ?>privacy.php">Privacy Policy</a><a href="<?= $base ?? '' ?>faq.php">FAQ</a></div>
    </div>
  <div class="footer-bottom"><div class="container">© <?= date('2023-2024') ?> Election Voice - Public Voice of India Official</div></div>
</footer>
<script src="<?= $base ?? '' ?>assets/app.js"></script>
</body></html>
