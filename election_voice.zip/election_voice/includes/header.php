<?php
$pageTitle = $pageTitle ?? 'Election Voice';
$base = $base ?? '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Election Voice - a transparent online voting system demonstration for academic projects.">
<title><?= e($pageTitle) ?> | Election Voice</title>
<link rel="stylesheet" href="<?= $base ?>assets/style.css">
</head>
<body>
<header class="site-header">
  <div class="container nav-wrap">
    <a class="brand" href="<?= $base ?>index.php"><img src="<?= $base ?>assets/election-voice-logo.png" alt="Election Voice logo"><span>Election <b>Voice</b></span></a>
    <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
    <nav class="main-nav">
      <a href="<?= $base ?>index.php">Home</a>
      <a href="<?= $base ?>about.php">About</a>
      <a href="<?= $base ?>insights.php">Insights</a>
      <a href="<?= $base ?>candidates.php">Candidates</a>
      <a href="<?= $base ?>user-manual.php">User Manual</a>
      <a href="<?= $base ?>contact.php">Contact</a>
      <?php if (!empty($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <a href="<?= $base ?>admin/dashboard.php">Dashboard</a>
      <?php elseif (!empty($_SESSION['role']) && $_SESSION['role'] === 'voter'): ?>
        <a href="<?= $base ?>voter/dashboard.php">My ballot</a>
      <?php endif; ?>
      <?php if (!empty($_SESSION['user_id'])): ?>
        <a class="nav-cta" href="<?= $base ?>logout.php">Logout</a>
      <?php else: ?>
        <a class="nav-cta" href="<?= $base ?>login.php">Login</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<?php if (!empty($_SESSION['flash'])): $f = $_SESSION['flash']; unset($_SESSION['flash']); ?>
  <div class="container"><div class="alert <?= e($f['type']) ?>"><?= e($f['message']) ?></div></div>
<?php endif; ?>
