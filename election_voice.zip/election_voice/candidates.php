<?php
declare(strict_types=1);

/*
 * Election Voice — Candidates page
 * Uses the existing shared header/footer and a PDO connection in config.php.
 * Adjust the candidate query/table column names to match your database schema.
 */
require_once __DIR__ . '/config.php';

$pageTitle = 'Candidates';
$base = '';

$candidates = [];
$loadError = false;

try {
    // Expected table: candidates(id, name, party, position, manifesto, photo, status)
    // Change these names if your existing schema differs.
    $stmt = $pdo->query(
        "SELECT id, name, party, position, manifesto, photo
         FROM candidates
         WHERE status = 'active'
         ORDER BY name ASC"
    );
    $candidates = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    // Log the detailed error privately; do not expose database details to visitors.
    error_log('Election Voice candidates page: ' . $e->getMessage());
    $loadError = true;
}

function ev_h(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

require __DIR__ . '/includes/header.php';
?>

<main class="ev-candidates-page">
    <section class="ev-candidates-hero">
        <div class="ev-hero-content">
            <span class="ev-eyebrow">ELECTION VOICE</span>
            <h1>Meet the <span>candidates</span></h1>
            <p>Learn about the candidates, explore their priorities, and make an informed choice.</p>
            <a class="ev-primary-btn" href="#candidate-list">Explore candidates <span aria-hidden="true">↓</span></a>
        </div>
        <div class="ev-hero-art" aria-hidden="true">
            <div class="ev-ballot-card">
                <div class="ev-ballot-top"><span></span><span></span><span></span></div>
                <div class="ev-ballot-check">✓</div>
                <div class="ev-ballot-line"></div>
                <div class="ev-ballot-line short"></div>
                <div class="ev-ballot-stamp">YOUR VOICE<br>MATTERS</div>
            </div>
            <div class="ev-orange-orb"></div>
        </div>
    </section>

    <section class="ev-candidate-section" id="candidate-list">
        <div class="ev-section-heading">
            <div>
                <span class="ev-eyebrow">GET TO KNOW THEM</span>
                <h2>Candidate directory</h2>
                <p>Review each profile and their stated priorities before you vote.</p>
            </div>
            <label class="ev-search-wrap">
                <span class="ev-search-icon" aria-hidden="true">⌕</span>
                <span class="ev-sr-only">Search candidates</span>
                <input id="candidateSearch" type="search" placeholder="Search by name or party…" autocomplete="off">
            </label>
        </div>

        <?php if ($loadError): ?>
            <div class="ev-notice" role="status">
                Candidate information is temporarily unavailable. Please try again later.
            </div>
        <?php elseif (!$candidates): ?>
            <div class="ev-empty-state">
                <div class="ev-empty-icon" aria-hidden="true">✓</div>
                <h3>Candidates will appear here</h3>
                <p>There are no active candidates to display yet. Please check back later.</p>
            </div>
        <?php else: ?>
            <div class="ev-candidate-grid" id="candidateGrid">
                <?php foreach ($candidates as $candidate):
                    $name = (string)($candidate['name'] ?? 'Candidate');
                    $party = (string)($candidate['party'] ?? 'Independent');
                    $position = (string)($candidate['position'] ?? '');
                    $manifesto = (string)($candidate['manifesto'] ?? '');
                    $photo = trim((string)($candidate['photo'] ?? ''));
                    // Only allow a local relative image path, not arbitrary external URLs.
                    $safePhoto = ($photo !== '' && !preg_match('~^(?:https?:)?//|^[a-z]+:~i', $photo))
                        ? $photo : '';
                    $initial = function_exists('mb_substr') ? mb_substr($name, 0, 1, 'UTF-8') : substr($name, 0, 1);
                ?>
                    <article class="ev-candidate-card"
                        data-search="<?= ev_h(strtolower($name . ' ' . $party . ' ' . $position)) ?>">
                        <div class="ev-candidate-card-top">
                            <span class="ev-candidate-label">CANDIDATE</span>
                            <span class="ev-card-mark" aria-hidden="true">EV</span>
                        </div>
                        <?php if ($safePhoto !== ''): ?>
                            <img class="ev-candidate-photo" src="<?= ev_h($safePhoto) ?>" alt="Photo of <?= ev_h($name) ?>" loading="lazy">
                        <?php else: ?>
                            <div class="ev-candidate-avatar" aria-hidden="true"><?= ev_h($initial) ?></div>
                        <?php endif; ?>
                        <div class="ev-candidate-details">
                            <h3><?= ev_h($name) ?></h3>
                            <p class="ev-party"><?= ev_h($party) ?></p>
                            <?php if ($position !== ''): ?>
                                <p class="ev-position"><?= ev_h($position) ?></p>
                            <?php endif; ?>
                            <?php if ($manifesto !== ''): ?>
                                <p class="ev-manifesto"><?= ev_h($manifesto) ?></p>
                            <?php else: ?>
                                <p class="ev-manifesto ev-muted">Candidate profile and priorities will be updated soon.</p>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <p class="ev-no-results" id="noCandidateResults" hidden>No candidates match your search.</p>
        <?php endif; ?>
        <p class="ev-disclaimer">Candidate details are provided for informational purposes. Please verify election information through the appropriate authorized source.</p>
    </section>
</main>

<style>
.ev-candidates-page{color:#171717;background:#fff;font-family:inherit}
.ev-candidates-page *{box-sizing:border-box}
.ev-candidates-hero{position:relative;isolation:isolate;overflow:hidden;display:flex;align-items:center;justify-content:space-between;gap:32px;min-height:350px;padding:clamp(28px,6vw,76px);background:#fff3e8;border-bottom:1px solid #ffe0c6}
.ev-hero-content{position:relative;z-index:2;max-width:620px}
.ev-eyebrow{display:inline-block;color:#d95e0b;font-size:.76rem;font-weight:800;letter-spacing:.14em}
.ev-candidates-hero h1{margin:14px 0;font-size:clamp(2.3rem,5vw,4.4rem);line-height:1.05;letter-spacing:-.045em}
.ev-candidates-hero h1 span{color:#f47721}
.ev-candidates-hero p{max-width:540px;color:#555;font-size:1.05rem;line-height:1.7}
.ev-primary-btn{display:inline-flex;align-items:center;gap:12px;margin-top:12px;padding:13px 19px;border-radius:9px;background:#f47721;color:#fff;text-decoration:none;font-weight:750;transition:background .2s,transform .2s}
.ev-primary-btn:hover{background:#d95e0b;transform:translateY(-1px)}
.ev-hero-art{position:relative;display:grid;place-items:center;flex:0 0 300px;min-height:245px}
.ev-orange-orb{position:absolute;width:245px;height:245px;border-radius:50%;background:#ffc18e;opacity:.7;right:0;top:0;z-index:-1}
.ev-ballot-card{position:relative;width:205px;padding:22px;background:#fff;border:1px solid #f4d9c5;border-radius:18px;box-shadow:0 22px 50px #8c4b251c;transform:rotate(5deg)}
.ev-ballot-top{display:flex;gap:5px;margin-bottom:24px}
.ev-ballot-top span{width:7px;height:7px;background:#f4b17e;border-radius:50%}
.ev-ballot-check{display:grid;place-items:center;width:66px;height:66px;margin:0 auto 18px;border:3px solid #f47721;border-radius:50%;color:#f47721;font-size:2.5rem;font-weight:800}
.ev-ballot-line{height:8px;margin:10px 0;border-radius:10px;background:#f0e5dc}
.ev-ballot-line.short{width:62%}
.ev-ballot-stamp{position:absolute;right:-30px;bottom:12px;padding:10px 12px;border:2px solid #f47721;border-radius:7px;background:#fff;color:#d95e0b;font-size:.65rem;font-weight:900;letter-spacing:.08em;transform:rotate(-10deg)}
.ev-candidate-section{max-width:1200px;margin:0 auto;padding:clamp(28px,5vw,64px) 22px}
.ev-section-heading{display:flex;justify-content:space-between;align-items:end;gap:24px;margin-bottom:28px}
.ev-section-heading h2{margin:8px 0;font-size:clamp(1.8rem,3vw,2.5rem);letter-spacing:-.03em}
.ev-section-heading p{margin:0;color:#666;line-height:1.6}
.ev-search-wrap{display:flex;align-items:center;gap:10px;width:min(100%,320px);padding:0 13px;border:1px solid #ddd;border-radius:10px;background:#fff}
.ev-search-icon{font-size:1.5rem;color:#888}
.ev-search-wrap input{width:100%;min-width:0;padding:13px 0;border:0;outline:0;background:transparent;color:#171717;font:inherit}
.ev-search-wrap:focus-within{border-color:#f47721;box-shadow:0 0 0 3px #f4772120}
.ev-candidate-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}
.ev-candidate-card{overflow:hidden;border:1px solid #eee0d6;border-radius:16px;background:#fff;box-shadow:0 8px 24px #2a1b1008;transition:transform .2s,box-shadow .2s}
.ev-candidate-card:hover{transform:translateY(-4px);box-shadow:0 15px 32px #2a1b1012}
.ev-candidate-card-top{display:flex;justify-content:space-between;align-items:center;padding:16px 18px 0}
.ev-candidate-label{font-size:.68rem;font-weight:800;letter-spacing:.12em;color:#b85a1d}
.ev-card-mark{display:grid;place-items:center;width:32px;height:32px;border-radius:9px;background:#fff0e4;color:#e66c18;font-size:.75rem;font-weight:900}
.ev-candidate-avatar,.ev-candidate-photo{display:block;width:104px;height:104px;margin:18px auto 12px;border-radius:50%;object-fit:cover}
.ev-candidate-avatar{display:grid;place-items:center;background:linear-gradient(135deg,#ffe1c7,#f47721);color:#fff;font-size:2.5rem;font-weight:800}
.ev-candidate-details{padding:0 22px 24px;text-align:center}
.ev-candidate-details h3{margin:8px 0 5px;font-size:1.25rem}
.ev-party{margin:0;color:#d95e0b;font-weight:750}
.ev-position{margin:7px 0;color:#666;font-size:.9rem}
.ev-manifesto{margin:16px 0 0;color:#555;font-size:.93rem;line-height:1.65;overflow-wrap:anywhere}
.ev-muted{color:#888}
.ev-empty-state{padding:48px 20px;text-align:center;border:1px dashed #edc6a7;border-radius:16px;background:#fffaf6}
.ev-empty-icon{display:grid;place-items:center;width:54px;height:54px;margin:0 auto 14px;border-radius:50%;background:#ffead9;color:#e66c18;font-size:1.7rem;font-weight:800}
.ev-empty-state h3{margin:0 0 8px}
.ev-empty-state p,.ev-notice{color:#666;line-height:1.6}
.ev-notice{padding:18px;border:1px solid #f0d0ba;border-radius:10px;background:#fff8f2}
.ev-no-results{text-align:center;padding:24px;color:#666}
.ev-disclaimer{margin:26px 0 0;color:#777;font-size:.82rem;line-height:1.6}
.ev-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
@media(max-width:900px){.ev-candidate-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.ev-hero-art{flex-basis:230px}.ev-orange-orb{width:210px;height:210px}}
@media(max-width:640px){.ev-candidates-hero{min-height:auto;padding:36px 22px}.ev-hero-art{display:none}.ev-section-heading{align-items:stretch;flex-direction:column}.ev-search-wrap{width:100%}.ev-candidate-grid{grid-template-columns:1fr}.ev-candidate-card{max-width:480px;width:100%;margin:0 auto}}
@media(prefers-reduced-motion:reduce){.ev-candidate-card,.ev-primary-btn{transition:none}}
</style>

<script>
(() => {
    const search = document.getElementById('candidateSearch');
    const grid = document.getElementById('candidateGrid');
    const noResults = document.getElementById('noCandidateResults');
    if (!search || !grid) return;

    const cards = Array.from(grid.querySelectorAll('.ev-candidate-card'));
    search.addEventListener('input', () => {
        const query = search.value.trim().toLocaleLowerCase();
        let visible = 0;
        cards.forEach(card => {
            const matches = (card.dataset.search || '').includes(query);
            card.hidden = !matches;
            if (matches) visible++;
        });
        if (noResults) noResults.hidden = visible !== 0;
    });
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
